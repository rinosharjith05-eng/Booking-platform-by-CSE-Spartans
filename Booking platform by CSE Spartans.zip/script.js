const form = document.getElementById('bookingForm');
const msg = document.getElementById('message');
const bookingsList = document.createElement('ul'); // create a list to show bookings
document.body.appendChild(bookingsList);

form.addEventListener('submit', (e) => {
  e.preventDefault();
  const name = form.querySelector('input[type="text"]').value;
  const date = form.querySelector('input[type="date"]').value;
  const time = document.getElementById('time').value;

  // Confirmation message
  msg.textContent = `✅ Booking Confirmed for ${name} on ${date} at ${time}`;
  msg.style.color = "yellow";

  // Add booking to the list
  const item = document.createElement('li');
  item.textContent = `${name} — ${date} — ${time}`;
  bookingsList.appendChild(item);

  form.reset();
});